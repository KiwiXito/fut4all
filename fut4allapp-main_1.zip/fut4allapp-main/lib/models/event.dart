class Event {
  String id;
  String name;
  String location;
  DateTime dateTime;
  int peopleNeeded;
  String description;
  double latitude;
  double longitude;
  String createdBy;
  int peopleJoined;

  Event({
    required this.id,
    required this.name,
    required this.location,
    required this.dateTime,
    required this.peopleNeeded,
    required this.description,
    required this.latitude,
    required this.longitude,
    required this.createdBy,
    this.peopleJoined = 0,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'location': location,
      'dateTime': dateTime.toIso8601String(),
      'peopleNeeded': peopleNeeded,
      'description': description,
      'latitude': latitude,
      'longitude': longitude,
      'createdBy': createdBy,
      'peopleJoined': peopleJoined,
    };
  }
}
