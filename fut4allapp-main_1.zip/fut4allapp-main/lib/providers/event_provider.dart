import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/event.dart';
import 'package:firebase_auth/firebase_auth.dart';

class EventProvider with ChangeNotifier {
  List<Event> _events = [];
  List<Event> _joinedEvents = [];
  final FirebaseAuth _auth = FirebaseAuth.instance;
  bool _joinedEventsFetched = false; // Flag to track if joined events are fetched

  List<Event> get events => _events;
  List<Event> get joinedEvents => _joinedEvents;

  Future<void> fetchEvents() async {
    try {
      final querySnapshot = await FirebaseFirestore.instance.collection('events').get();
      _events = querySnapshot.docs.map((doc) {
        final data = doc.data() as Map<String, dynamic>;
        return Event(
          id: doc.id,
          name: data['name'] ?? 'Unnamed Event',
          location: data['location'] ?? 'Unknown Location',
          dateTime: data['dateTime'] != null ? DateTime.parse(data['dateTime']) : DateTime.now(),
          peopleNeeded: data['peopleNeeded'] ?? 0,
          description: data['description'] ?? '',
          latitude: data['latitude'] ?? 0.0,
          longitude: data['longitude'] ?? 0.0,
          createdBy: data['createdBy'] ?? 'Unknown',
          peopleJoined: data['peopleJoined'] ?? 0,
        );
      }).toList();
      if (!_joinedEventsFetched) {
        await fetchJoinedEvents();
      }
      notifyListeners();
    } catch (e) {
      print('Error fetching events: $e');
    }
  }

  Future<void> fetchJoinedEvents() async {
    final user = _auth.currentUser;
    if (user == null) {
      print('No user is currently signed in.');
      return;
    }

    try {
      final querySnapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .collection('joinedEvents')
          .get();

      final joinedEventIds = querySnapshot.docs.map((doc) => doc.id).toList();
      print('Joined event IDs: $joinedEventIds');

      _joinedEvents = _events.where((event) => joinedEventIds.contains(event.id)).toList();
      _joinedEventsFetched = true; // Set flag to true after fetching joined events
      notifyListeners();
    } catch (e) {
      print('Error fetching joined events: $e');
    }
  }

  Future<void> addEvent(Event event) async {
    try {
      await FirebaseFirestore.instance.collection('events').doc(event.id).set(event.toMap());
      _events.add(event);
      notifyListeners();
    } catch (e) {
      print('Error adding event: $e');
    }
  }

  Future<void> joinEvent(String eventId) async {
    final user = _auth.currentUser;
    if (user == null) {
      print('No user is currently signed in.');
      return;
    }

    try {
      final eventDoc = FirebaseFirestore.instance.collection('events').doc(eventId);
      await FirebaseFirestore.instance.runTransaction((transaction) async {
        final snapshot = await transaction.get(eventDoc);
        if (!snapshot.exists) {
          throw Exception("Event does not exist!");
        }

        final data = snapshot.data() as Map<String, dynamic>;
        int currentPeopleJoined = data['peopleJoined'] ?? 0;
        transaction.update(eventDoc, {'peopleJoined': currentPeopleJoined + 1});

        // Save joined event for the user
        final userDoc = FirebaseFirestore.instance.collection('users').doc(user.uid);
        transaction.set(userDoc.collection('joinedEvents').doc(eventId), {'joinedAt': FieldValue.serverTimestamp()});
      });

      _joinedEvents.add(_events.firstWhere((event) => event.id == eventId));
      notifyListeners();
    } catch (e) {
      print('Error joining event: $e');
    }
  }

  Future<void> leaveEvent(String eventId) async {
    final user = _auth.currentUser;
    if (user == null) {
      print('No user is currently signed in.');
      return;
    }

    try {
      final eventDoc = FirebaseFirestore.instance.collection('events').doc(eventId);
      await FirebaseFirestore.instance.runTransaction((transaction) async {
        final snapshot = await transaction.get(eventDoc);
        if (!snapshot.exists) {
          throw Exception("Event does not exist!");
        }

        final data = snapshot.data() as Map<String, dynamic>;
        int currentPeopleJoined = data['peopleJoined'] ?? 0;
        if (currentPeopleJoined > 0) {
          transaction.update(eventDoc, {'peopleJoined': currentPeopleJoined - 1});
        }

        // Remove joined event for the user
        final userDoc = FirebaseFirestore.instance.collection('users').doc(user.uid);
        transaction.delete(userDoc.collection('joinedEvents').doc(eventId));
      });

      _joinedEvents.removeWhere((event) => event.id == eventId);
      notifyListeners();
    } catch (e) {
      print('Error leaving event: $e');
    }
  }

  Future<void> deleteEvent(String eventId) async {
    try {
      await FirebaseFirestore.instance.collection('events').doc(eventId).delete();
      _events.removeWhere((event) => event.id == eventId);
      notifyListeners();
    } catch (e) {
      print('Error deleting event: $e');
    }
  }

  bool isEventJoined(String eventId) {
    return _joinedEvents.any((event) => event.id == eventId);
  }

  Future<void> logout() async {
    try {
      await _auth.signOut();
      _events = [];
      _joinedEvents = [];
      _joinedEventsFetched = false;
      notifyListeners();
    } catch (e) {
      print('Error signing out: $e');
    }
  }
}
