import 'package:flutter/material.dart';
import 'package:google_maps_webservice/places.dart';

class PlacesSearchScreen extends StatefulWidget {
  @override
  _PlacesSearchScreenState createState() => _PlacesSearchScreenState();
}

class _PlacesSearchScreenState extends State<PlacesSearchScreen> {
  final _places = GoogleMapsPlaces(apiKey: 'AIzaSyCWxNnB2vMsf0tF_m7GBtaoyfrtZr0fIlU');
  List<PlacesSearchResult> _placesList = [];
  bool _isLoading = false;
  String _errorMessage = '';

  @override
  void initState() {
    super.initState();
    _searchFootballPlaces();
  }

  void _searchFootballPlaces() async {
    try {
      await _searchPlaces('football fields in Barcelona', 0);
    } catch (error) {
      setState(() {
        _errorMessage = 'Error: $error';
        print(error); // Log the error for debugging purposes
      });
    }
  }

  Future<void> _searchPlaces(String query, int retryCount) async {
    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });

    try {
      final response = await _places.searchByText(query);
      if (response.status == 'OK') {
        setState(() {
          _placesList = response.results;
        });
      } else {
        setState(() {
          _errorMessage = 'Error: ${response.errorMessage} (Status: ${response.status})';
        });
      }
    } on Exception catch (error) {
      // Handle network or other unexpected errors
      if (retryCount < 3) {
        // Implement exponential backoff retry logic
        const durations = [Duration(seconds: 1), Duration(seconds: 5), Duration(seconds: 20)];
        await Future.delayed(durations[retryCount]);
        retryCount++;
        await _searchPlaces(query, retryCount); // Asegúrate de usar 'await' aquí también
      } else {
        setState(() {
          _errorMessage = 'An unexpected error occurred: $error';
          print(error); // Log the error for debugging purposes
        });
      }
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _handleSearch(String query) {
    _searchPlaces(query, 0);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Search Places'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              decoration: InputDecoration(
                labelText: 'Search',
                border: OutlineInputBorder(),
                suffixIcon: Icon(Icons.search),
              ),
              onSubmitted: _handleSearch,
            ),
          ),
          if (_isLoading) CircularProgressIndicator(),
          if (_errorMessage.isNotEmpty)
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(_errorMessage, style: TextStyle(color: Colors.red)),
            ),
          Expanded(
            child: _placesList.isEmpty && !_isLoading && _errorMessage.isEmpty
                ? Center(child: Text('No se encontraron lugares'))
                : ListView.builder(
                    itemCount: _placesList.length,
                    itemBuilder: (context, index) {
                      final place = _placesList[index];
                      return ListTile(
                        title: Text(place.name),
                        subtitle: Text(place.formattedAddress ?? ''),
                        onTap: () {
                          Navigator.pop(context, place);
                        },
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
