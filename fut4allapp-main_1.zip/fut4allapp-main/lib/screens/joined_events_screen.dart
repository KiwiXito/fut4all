import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/event_provider.dart';
import '../models/event.dart';

class JoinedEventListScreen extends StatefulWidget {
  @override
  _JoinedEventListScreenState createState() => _JoinedEventListScreenState();
}

class _JoinedEventListScreenState extends State<JoinedEventListScreen> {
  @override
  void initState() {
    super.initState();
    // Fetch joined events only once when the widget is first created
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<EventProvider>(context, listen: false).fetchJoinedEvents();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green[50], // Cambiar el color de fondo de la pantalla
      body: Consumer<EventProvider>(
        builder: (context, eventProvider, child) {
          if (eventProvider.joinedEvents.isEmpty) {
            return Center(
              child: Text('No joined events available.'),
            );
          }

          return ListView.builder(
            itemCount: eventProvider.joinedEvents.length,
            itemBuilder: (context, index) {
              final event = eventProvider.joinedEvents[index];
              return Card(
                margin: EdgeInsets.all(10.0),
                elevation: 5.0,
                color: Colors.green[100], // Cambiar el color de la tarjeta
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15.0),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        event.name,
                        style: TextStyle(
                          fontSize: 20.0,
                          fontWeight: FontWeight.bold,
                          color: Colors.green[800], // Cambiar el color del texto
                        ),
                      ),
                      SizedBox(height: 10.0),
                      Row(
                        children: [
                          Icon(Icons.location_on, color: Colors.green[600]),
                          SizedBox(width: 5.0),
                          Text(
                            event.location,
                            style: TextStyle(fontSize: 16.0, color: Colors.grey[600]),
                          ),
                        ],
                      ),
                      SizedBox(height: 10.0),
                      Row(
                        children: [
                          Icon(Icons.date_range, color: Colors.green[600]),
                          SizedBox(width: 5.0),
                          Text(
                            event.dateTime.toLocal().toString().split(' ')[0],
                            style: TextStyle(fontSize: 16.0, color: Colors.grey[600]),
                          ),
                        ],
                      ),
                      SizedBox(height: 10.0),
                      Row(
                        children: [
                          Icon(Icons.people, color: Colors.green[600]),
                          SizedBox(width: 5.0),
                          Text(
                            'People joined: ${event.peopleJoined}/${event.peopleNeeded}',
                            style: TextStyle(fontSize: 16.0, color: Colors.grey[600]),
                          ),
                        ],
                      ),
                      SizedBox(height: 10.0),
                      Text(
                        event.description,
                        style: TextStyle(fontSize: 16.0, color: Colors.grey[800]),
                      ),
                      SizedBox(height: 10.0),
                      Align(
                        alignment: Alignment.centerRight,
                        child: ElevatedButton(
                          onPressed: () async {
                            await Provider.of<EventProvider>(context, listen: false).leaveEvent(event.id);
                          },
                          child: Text('Leave Event',
                      style: TextStyle(fontSize: 16.0, color: Colors.white)),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.red, // Cambiar el color del botón
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
