import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../providers/event_provider.dart';
import '../models/event.dart';
import 'dart:math';

class MapScreen extends StatefulWidget {
  @override
  _MapScreenState createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  late GoogleMapController _mapController;
  final Map<String, Marker> _markers = {};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<EventProvider>(context, listen: false).fetchEvents().then((_) {
        _loadMarkers();
      });
    });
  }

  void _loadMarkers() {
    final events = Provider.of<EventProvider>(context, listen: false).events;
    final groupedEvents = _groupEventsByLocation(events);

    setState(() {
      _markers.clear();
      groupedEvents.forEach((location, events) {
        for (int i = 0; i < events.length; i++) {
          final event = events[i];
          final marker = Marker(
            markerId: MarkerId('${event.id}_$i'),
            position: _getOffsetPosition(LatLng(event.latitude, event.longitude), i),
            infoWindow: InfoWindow(
              title: '${event.location} (${events.length} events)',
              snippet: event.name,
              onTap: () => _showEventsDialog(events),
            ),
          );
          _markers['${event.id}_$i'] = marker;
        }
      });
    });
  }

  LatLng _getOffsetPosition(LatLng position, int index) {
    const double offsetDistance = 0.0001;
    final double offsetX = cos(index * pi / 6) * offsetDistance;
    final double offsetY = sin(index * pi / 6) * offsetDistance;
    return LatLng(position.latitude + offsetX, position.longitude + offsetY);
  }

  Map<String, List<Event>> _groupEventsByLocation(List<Event> events) {
    final Map<String, List<Event>> groupedEvents = {};
    for (var event in events) {
      if (groupedEvents.containsKey(event.location)) {
        groupedEvents[event.location]!.add(event);
      } else {
        groupedEvents[event.location] = [event];
      }
    }
    return groupedEvents;
  }

  void _showEventsDialog(List<Event> events) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Events at ${events.first.location}'),
          content: Container(
            width: double.maxFinite,
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: events.length,
              itemBuilder: (context, index) {
                final event = events[index];
                return Card(
                  child: ListTile(
                    title: Text(event.name, style: TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(height: 4),
                        Text('Date: ${event.dateTime.toLocal().toString().split(' ')[0]}'),
                        Text('People needed: ${event.peopleNeeded}'),
                        Text('Description: ${event.description}'),
                      ],
                    ),
                    trailing: event.peopleJoined < event.peopleNeeded && !Provider.of<EventProvider>(context, listen: false).isEventJoined(event.id)
                        ? ElevatedButton(
                            onPressed: () {
                              Provider.of<EventProvider>(context, listen: false).joinEvent(event.id);
                            },
                            child: Text('Join'),
                          )
                        : null,
                  ),
                );
              },
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text('Close'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GoogleMap(
        onMapCreated: (controller) {
          _mapController = controller;
          _mapController.setMapStyle(_mapStyle);
        },
        initialCameraPosition: CameraPosition(
          target: LatLng(41.3851, 2.1734), // Coordenadas de Barcelona
          zoom: 12,
        ),
        markers: _markers.values.toSet(),
      ),
    );
  }

  final String _mapStyle = '''
  [
    {
      "featureType": "poi",
      "stylers": [
        { "visibility": "off" }
      ]
    },
    {
      "featureType": "poi.business",
      "stylers": [
        { "visibility": "off" }
      ]
    },
    {
      "featureType": "poi.park",
      "stylers": [
        { "visibility": "off" }
      ]
    },
    {
      "featureType": "poi.attraction",
      "stylers": [
        { "visibility": "off" }
      ]
    },
    {
      "featureType": "poi.place_of_worship",
      "stylers": [
        { "visibility": "off" }
      ]
    }
  ]
  ''';
}
