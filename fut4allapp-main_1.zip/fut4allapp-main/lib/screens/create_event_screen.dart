import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../providers/event_provider.dart';
import '../models/event.dart';

class CreateEventScreen extends StatefulWidget {
  @override
  _CreateEventScreenState createState() => _CreateEventScreenState();
}

class _CreateEventScreenState extends State<CreateEventScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _peopleNeededController = TextEditingController();
  final _descriptionController = TextEditingController();
  DateTime _selectedDate = DateTime.now();
  TimeOfDay _selectedTime = TimeOfDay.now();
  String? _selectedField;

  final List<Map<String, dynamic>> footballFields = [
    {
      'name': 'Camp Municipal de Futbol de Badalona',
      'address': 'Carrer de la via Augusta, 2, 08915 Badalona, Barcelona',
      'latitude': 41.4549,
      'longitude': 2.2471,
    },
    {
      'name': 'Campo de Futbol de Barcelona',
      'address': 'Dirección ficticia, Barcelona',
      'latitude': 41.3851,
      'longitude': 2.1734,
    },
    {
      'name': 'Camp Nou',
      'address': 'C. d\'Arístides Maillol, 12, 08028 Barcelona',
      'latitude': 41.3809,
      'longitude': 2.1228,
    },
    {
      'name': 'Estadi Olímpic Lluís Companys',
      'address': 'Passeig Olímpic, 15-17, 08038 Barcelona',
      'latitude': 41.3643,
      'longitude': 2.1553,
    },
    {
      'name': 'Camp Municipal de Futbol Nou Sardenya',
      'address': 'Carrer dels Esports, s/n, 08017 Barcelona',
      'latitude': 41.4068,
      'longitude': 2.1454,
    },
    {
      'name': 'Camp Municipal de Futbol Canyelles',
      'address': 'Carrer de Federico García Lorca, s/n, 08042 Barcelona',
      'latitude': 41.4515,
      'longitude': 2.1685,
    },
    {
      'name': 'Camp Municipal de Futbol La Satàlia',
      'address': 'Carrer de Margarit, 61, 08004 Barcelona',
      'latitude': 41.3736,
      'longitude': 2.1632,
    },
    {
      'name': 'Campo de Futbol de la Vall d\'Hebron',
      'address': 'Passeig de la Vall d\'Hebron, 178, 08035 Barcelona',
      'latitude': 41.4296,
      'longitude': 2.1390,
    },
    {
      'name': 'Campo de Futbol Municipal de Horta',
      'address': 'Carrer de Feliu i Codina, 27, 08031 Barcelona',
      'latitude': 41.4291,
      'longitude': 2.1599,
    },
    {
      'name': 'Campo de Futbol de La Guineueta',
      'address': 'Carrer de Garcilaso, 53, 08027 Barcelona',
      'latitude': 41.4295,
      'longitude': 2.1780,
    },
    // Añadir más campos según sea necesario
  ];

  @override
  void dispose() {
    _nameController.dispose();
    _peopleNeededController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  Future<void> _submitForm() async {
    if (_formKey.currentState!.validate()) {
      final selectedFieldData =
          footballFields.firstWhere((field) => field['name'] == _selectedField);

      final user = FirebaseAuth.instance.currentUser;
      final DateTime eventDateTime = DateTime(
        _selectedDate.year,
        _selectedDate.month,
        _selectedDate.day,
        _selectedTime.hour,
        _selectedTime.minute,
      );

      final newEvent = Event(
        id: Uuid().v4(),
        name: _nameController.text,
        location: _selectedField!,
        dateTime: eventDateTime,
        peopleNeeded: int.parse(_peopleNeededController.text),
        description: _descriptionController.text,
        latitude: selectedFieldData['latitude'],
        longitude: selectedFieldData['longitude'],
        createdBy: user!.uid,
      );

      try {
        await FirebaseFirestore.instance
            .collection('events')
            .doc(newEvent.id)
            .set(newEvent.toMap());
        Provider.of<EventProvider>(context, listen: false).addEvent(newEvent);
        Navigator.pop(context);
      } catch (error) {
        print('Error saving event: $error');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to save event: $error')),
        );
      }
    }
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime.now(),
      lastDate: DateTime(2101),
    );
    if (pickedDate != null && pickedDate != _selectedDate) {
      setState(() {
        _selectedDate = pickedDate;
      });
    }
  }

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? pickedTime = await showTimePicker(
      context: context,
      initialTime: _selectedTime,
    );
    if (pickedTime != null && pickedTime != _selectedTime) {
      setState(() {
        _selectedTime = pickedTime;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Create Event'),
        backgroundColor: Colors.green[700],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Event Details',
                style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.green[800]),
              ),
              SizedBox(height: 20),
              TextFormField(
                controller: _nameController,
                decoration: InputDecoration(
                  labelText: 'Event Name',
                  border: OutlineInputBorder(),
                  labelStyle: TextStyle(color: Colors.green[700]),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.green[700]!),
                  ),
                ),
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Please enter a name';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              DropdownButtonFormField<String>(
                decoration: InputDecoration(
                  labelText: 'Select a football field',
                  border: OutlineInputBorder(),
                  labelStyle: TextStyle(color: Colors.green[700]),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.green[700]!),
                  ),
                ),
                items: footballFields.map((field) {
                  return DropdownMenuItem<String>(
                    value: field['name'],
                    child: Text(field['name']!),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    _selectedField = value;
                  });
                },
                value: _selectedField,
                validator: (value) {
                  if (value == null) {
                    return 'Please select a football field';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              TextFormField(
                controller: _peopleNeededController,
                decoration: InputDecoration(
                  labelText: 'Number of People Needed',
                  border: OutlineInputBorder(),
                  labelStyle: TextStyle(color: Colors.green[700]),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.green[700]!),
                  ),
                ),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Please enter the number of people needed';
                  }
                  if (int.tryParse(value) == null) {
                    return 'Please enter a valid number';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              TextFormField(
                controller: _descriptionController,
                decoration: InputDecoration(
                  labelText: 'Description',
                  border: OutlineInputBorder(),
                  labelStyle: TextStyle(color: Colors.green[700]),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.green[700]!),
                  ),
                ),
                maxLines: 3,
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Please enter a description';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: () => _selectDate(context),
                      icon: Icon(Icons.calendar_today, color: Colors.white),
                      label: Text('Select Date',
                          style:
                              TextStyle(fontSize: 16.0, color: Colors.white)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green[700],
                      ),
                    ),
                  ),
                  SizedBox(width: 20),
                  Text(
                    'Selected Date: ${_selectedDate.toLocal()}'.split(' ')[0],
                    style: TextStyle(fontSize: 16, color: Colors.green[800]),
                  ),
                ],
              ),
              SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: () => _selectTime(context),
                      icon: Icon(Icons.access_time, color: Colors.white),
                      label: Text('Select Time',
                          style:
                              TextStyle(fontSize: 16.0, color: Colors.white)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green[700],
                      ),
                    ),
                  ),
                  SizedBox(width: 20),
                  Text(
                    'Selected Time: ${_selectedTime.format(context)}',
                    style: TextStyle(fontSize: 16, color: Colors.green[800]),
                  ),
                ],
              ),
              SizedBox(height: 40),
              Center(
                child: ElevatedButton(
                  onPressed: _submitForm,
                  child: Text('Create Event',
                      style: TextStyle(fontSize: 16.0, color: Colors.white)),
                  style: ElevatedButton.styleFrom(
                    padding: EdgeInsets.symmetric(horizontal: 40, vertical: 20),
                    backgroundColor: Colors.green[700],
                    textStyle: TextStyle(fontSize: 18),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
