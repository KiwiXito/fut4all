import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

Future<BitmapDescriptor> getBitmapDescriptorFromIconData(
  IconData iconData, Color color) async {
  final pictureRecorder = PictureRecorder();
  final canvas = Canvas(pictureRecorder);
  final paint = Paint()..color = color;
  final textPainter = TextPainter(textDirection: TextDirection.ltr);
  final icon = String.fromCharCode(iconData.codePoint);
  textPainter.text = TextSpan(
    text: icon,
    style: TextStyle(
      fontSize: 48.0,
      fontFamily: iconData.fontFamily,
      color: color,
    ),
  );
  textPainter.layout();
  textPainter.paint(canvas, Offset.zero);
  final picture = pictureRecorder.endRecording();
  final image = await picture.toImage(48, 48);
  final byteData = await image.toByteData(format: ImageByteFormat.png);
  final buffer = byteData!.buffer.asUint8List();
  return BitmapDescriptor.fromBytes(buffer);
}
