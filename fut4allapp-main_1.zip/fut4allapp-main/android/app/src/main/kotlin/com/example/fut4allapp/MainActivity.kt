package com.example.fut4allapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
